#!bin/bash

git ls-files -o --ignored --exclude-standard

