/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jibanez- <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/30 11:44:25 by jibanez-          #+#    #+#             */
/*   Updated: 2020/10/30 11:48:50 by jibanez-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int i;
	int j;
	int tik;
	int flag;
	char *temp;

	i = 0;
	j = 0;
	flag = 0;
	while (str[i] != '\0')
	{
		while (to_find[j] != '\0' && str[i] == to_find[j])
		{
			++j;
			++i;
		}
		if (to_find[j] == '\0')
			flag = 1;
		i++;
		if (flag == 0)
			return (0);
		else if (flag)
			temp = to_find + str[i];
	}
	return (temp);
}


#include <stdbool.h>

char	*ft_strstr(char *str, char *to_find)
{
	char *haystack;
	char *needle;

	if (*to_find == '\0')
		return (str);

	haystack = str;
	needle = to_find;
	while (true)
	{
		if (*needle == '\0')
			return ((char *)(haystack - (needle - to_find)));
		if (*haystack == *needle)
			needle++;
		else
			needle = to_find;
		if (*haystack == '\0')
			break ;
		haystack++;
	}
	return (0);
}