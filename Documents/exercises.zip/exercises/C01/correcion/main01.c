void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

int	main(void)
{
	int *********nbr;

	ft_ultimate_ft(nbr);
	printf("%d",*********nbr);
}