#include <stdio.h>
#include <stdlib.h>
#include <string.h>

unsigned int	ft_strlcpy(char *dest, char *src, unsigned int size);

int main()
{
	char *src = malloc(2 * sizeof(src));

    strcpy(src, "SaLuT, comment tu vas ? 42mots quarante-deux; cinquante+et+un");
    printf("%s", ft_strcapitalize(src));

	free(src);
    
	return (0);
}