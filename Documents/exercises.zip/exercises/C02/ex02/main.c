#include <stdio.h>

int	ft_str_is_alpha(char *str);

int main(void)
{
    char *src = "";
    printf("%d", ft_str_is_alpha(src));
    return (0);
}