

char	*ft_strcpy(char *dest, char *src);

int main(void)
{
    char *src = "Hello World";
    char dest[12];
    ft_strcpy(dest, src);
    printf("%s", dest);
    return (0);
}