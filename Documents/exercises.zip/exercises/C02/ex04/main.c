#include <stdio.h>

int	ft_str_is_uppercase(char *str);

int main(void)
{
    char *src = "AaAAAAA";
    printf("%d", ft_str_is_uppercase(src));
    return (0);
}