#include <stdio.h>

char 	*ft_strncpy(char *dest, char *src, unsigned int n);

int main(void)
{
    char *src = "Hello World";
    char dest[12];
    ft_strcpy(dest, src);
    printf("%s", dest, 5);
    return (0);
}