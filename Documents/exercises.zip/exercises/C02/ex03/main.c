#include <stdio.h>

int	ft_str_is_numeric(char *str);

int main(void)
{
    char *src = "123";
    printf("%d", ft_str_is_numeric(src));
    return (0);
}