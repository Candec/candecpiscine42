#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strcapitalize(char *str);

int main()
{
	char *src = malloc(2 * sizeof(src));

    strcpy(src, "SaLuT, comment tu vas ? 42mots quarante-deux; cinquante+et+un");
    printf("%s", ft_strcapitalize(src));

	free(src);
    
	return (0);
}