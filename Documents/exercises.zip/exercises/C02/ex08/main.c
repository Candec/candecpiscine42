#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strlowcase(char *str);

int main()
{
	char *src = malloc(2 * sizeof(src));

    strcpy(src, "AaABbCcDdEeFfGg");
    ft_strlowcase(src);
    printf("%s", ft_strlowcase(src));

	free(src);
    
	return (0);
}