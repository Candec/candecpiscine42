#include <stdio.h>

int ft_str_is_printable(char *str);

int main(void)
{
    char *src = " ";
    ft_str_is_printable(src);
    printf("%d", ft_str_is_printable(src));
    return (0);
}