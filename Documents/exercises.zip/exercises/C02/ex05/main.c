#include <stdio.h>

int	ft_str_is_lowercase(char *str);

int main(void)
{
    char *src = "aaaaaaa";
    printf("%d", ft_str_is_lowercase(src));
    return (0);
}