#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char	*ft_strupcase(char *str);

int main()
{
	char *src = malloc(2 * sizeof(src));

    strcpy(src, "AaABbCcDdEeFfGg");
    printf("%s", ft_strupcase(src));

	free(src);
    
	return (0);
}